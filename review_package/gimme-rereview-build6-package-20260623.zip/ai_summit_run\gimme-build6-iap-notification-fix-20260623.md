# Gimme Build 6 修正設計 2026-06-23

## 目的

Build 5で残ったクロエ指摘のうち、商業品質を直接止めている2点だけを修正する。

1. `StoreEntitlementBridge` が足場だけで、購入/復元/購入更新処理が存在しない。
2. `NativeReminderBridge` が足場だけで、通知初期化/権限要求/OS通知スケジュール処理が存在しない。

## 実装方針

- Web確認版は引き続き購入を発生させず、`PreviewEntitlementRepository` でPlus体験を確認する。
- Android/iOSなど非Webでは `in_app_purchase` を使い、`gimme_plus_monthly` の商品取得、購入開始、購入更新監視、復元、購入完了処理を行う。
- Plus権限は購入更新で `purchased/restored` が確認できた時に `EntitlementSource.store` として保存する。
- 通知は `flutter_local_notifications` を初期化し、権限を要求し、`buildReminderPlan` の予定を `zonedSchedule` に渡す。
- Web確認版ではOS通知を無理に発火せず、通知予定リストの保存に留める。
- 既存の計算ロジック、医療費/児童手当/サブスク安全側判定は壊さない。

## Build 6 完了条件

- `flutter pub get`
- `dart format lib test`
- `flutter analyze`
- `flutter test`
- `flutter build web --base-href /ai-summit-gimme-20260622/`
- 公開プレビューが `1.2.0+6`
- クロエへBuild 6として再レビュー依頼
