import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

const gimmePlusProductId = 'gimme_plus_monthly';
const gimmePreviewEntitlementKey = 'premiumUnlocked';
const gimmeEntitlementSourceKey = 'entitlementSource';
const gimmeRemindersEnabledKey = 'remindersEnabled';

enum EntitlementSource { free, webPreview, store }

class EntitlementSnapshot {
  const EntitlementSnapshot({
    required this.unlocked,
    required this.source,
    required this.detail,
  });

  const EntitlementSnapshot.free()
    : unlocked = false,
      source = EntitlementSource.free,
      detail = '無料版';

  final bool unlocked;
  final EntitlementSource source;
  final String detail;

  bool get isPreview => source == EntitlementSource.webPreview;

  String get badgeLabel {
    switch (source) {
      case EntitlementSource.free:
        return 'Free';
      case EntitlementSource.webPreview:
        return 'Web確認版 Plus';
      case EntitlementSource.store:
        return 'Store Plus';
    }
  }
}

class PreviewEntitlementRepository {
  const PreviewEntitlementRepository(this.preferences);

  final SharedPreferences preferences;

  Future<EntitlementSnapshot> load() async {
    final unlocked = preferences.getBool(gimmePreviewEntitlementKey) ?? false;
    final sourceName =
        preferences.getString(gimmeEntitlementSourceKey) ??
        EntitlementSource.free.name;
    final source = EntitlementSource.values.firstWhere(
      (item) => item.name == sourceName,
      orElse: () =>
          unlocked ? EntitlementSource.webPreview : EntitlementSource.free,
    );
    if (!unlocked) {
      return const EntitlementSnapshot.free();
    }
    return EntitlementSnapshot(
      unlocked: true,
      source: source == EntitlementSource.store
          ? EntitlementSource.store
          : EntitlementSource.webPreview,
      detail: source == EntitlementSource.store ? 'ストア購入で有効' : 'Web確認版のプレビュー権限',
    );
  }

  Future<EntitlementSnapshot> setPreviewUnlocked(bool value) async {
    await preferences.setBool(gimmePreviewEntitlementKey, value);
    await preferences.setString(
      gimmeEntitlementSourceKey,
      value ? EntitlementSource.webPreview.name : EntitlementSource.free.name,
    );
    if (!value) {
      return const EntitlementSnapshot.free();
    }
    return const EntitlementSnapshot(
      unlocked: true,
      source: EntitlementSource.webPreview,
      detail: 'Web確認版のプレビュー権限',
    );
  }
}

class StoreEntitlementBridge {
  StoreEntitlementBridge({InAppPurchase? inAppPurchase})
    : _inAppPurchase = inAppPurchase ?? InAppPurchase.instance;

  final InAppPurchase _inAppPurchase;

  Stream<List<PurchaseDetails>> get purchaseStream =>
      _inAppPurchase.purchaseStream;

  Future<bool> isStoreAvailable() {
    if (kIsWeb) {
      return Future.value(false);
    }
    return _inAppPurchase.isAvailable();
  }

  Future<ProductDetailsResponse> loadPlusProduct() {
    return _inAppPurchase.queryProductDetails({gimmePlusProductId});
  }
}

class ReminderSettingsRepository {
  const ReminderSettingsRepository(this.preferences);

  final SharedPreferences preferences;

  bool loadEnabled() {
    return preferences.getBool(gimmeRemindersEnabledKey) ?? false;
  }

  Future<void> setEnabled(bool value) {
    return preferences.setBool(gimmeRemindersEnabledKey, value);
  }
}

class NativeReminderBridge {
  NativeReminderBridge({FlutterLocalNotificationsPlugin? plugin})
    : _plugin = plugin ?? FlutterLocalNotificationsPlugin();

  final FlutterLocalNotificationsPlugin _plugin;

  bool get canUseNativeNotifications => !kIsWeb;

  FlutterLocalNotificationsPlugin get plugin => _plugin;
}
